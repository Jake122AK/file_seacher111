r"""
FileSearcher — Windows用 全文検索ツール
========================================
- 指定フォルダ（ローカル / ネットワーク \\server\share）配下を再帰スキャン
- テキスト & Office (.docx/.xlsx/.pptx) & PDF を抽出
- SQLite FTS5 でインデックス化 → 2回目以降の検索は一瞬
- ファイル名 / 中身の両方にヒット、該当箇所のスニペットを表示
- 増分インデックス（mtime比較で変更分だけ再処理）

実行: python file_searcher.py
"""

from __future__ import annotations

import os
import sys
import re
import sqlite3
import subprocess
import threading
import queue
import time
import json
import traceback
from concurrent.futures import ThreadPoolExecutor, FIRST_COMPLETED, wait
from pathlib import Path
from datetime import datetime

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext

# ---------------------------------------------------------------------------
# 設定
# ---------------------------------------------------------------------------

APP_NAME = "FileSearcher"
APP_DIR = Path.home() / ".file_searcher"
APP_DIR.mkdir(exist_ok=True)
DB_PATH = APP_DIR / "index.db"
CONFIG_PATH = APP_DIR / "config.json"

MAX_FILE_SIZE = 50 * 1024 * 1024   # 50MB を超えるファイルは中身を読まない
SNIPPET_LEN = 30                    # スニペットの単語数
SEARCH_LIMIT = 500                  # 一回の検索でヒットさせる最大件数
NUM_EXTRACT_WORKERS = 8             # 並列でテキスト抽出するスレッド数
BATCH_SIZE = 100                    # DBへの一括書き込みサイズ

# テキストとして読むファイル拡張子
TEXT_EXT = {
    ".txt", ".md", ".markdown", ".rst", ".csv", ".tsv", ".log",
    ".json", ".jsonl", ".xml", ".yaml", ".yml", ".toml", ".ini", ".cfg", ".conf", ".env",
    ".html", ".htm", ".css", ".scss", ".sass", ".less",
    ".js", ".mjs", ".cjs", ".ts", ".tsx", ".jsx", ".vue", ".svelte",
    ".py", ".pyw", ".rb", ".php", ".pl", ".lua",
    ".c", ".cpp", ".cxx", ".cc", ".h", ".hpp", ".hxx",
    ".java", ".kt", ".scala", ".groovy", ".cs", ".fs", ".vb",
    ".go", ".rs", ".swift", ".m", ".mm",
    ".sql", ".psql",
    ".sh", ".bash", ".zsh", ".bat", ".cmd", ".ps1",
    ".r", ".jl", ".dart", ".tex", ".bib",
    ".gitignore", ".dockerfile", ".editorconfig",
}
OFFICE_EXT = {".docx", ".xlsx", ".pptx", ".pdf", ".doc", ".xls", ".ppt", ".rtf"}

# 走査をスキップするディレクトリ
SKIP_DIRS = {
    "node_modules", ".git", ".svn", ".hg", "__pycache__",
    ".venv", "venv", "env", ".env",
    ".idea", ".vscode", ".vs",
    "dist", "build", "out", "target", ".next", ".nuxt", ".cache",
    "System Volume Information", "$RECYCLE.BIN", "$Recycle.Bin",
    "AppData",
}

# ---------------------------------------------------------------------------
# テキスト抽出
# ---------------------------------------------------------------------------

def extract_text(path: Path) -> str | None:
    """各種ファイルからテキストを取り出す。読めなければ None。"""
    try:
        size = path.stat().st_size
    except OSError:
        return None
    if size > MAX_FILE_SIZE:
        return None

    ext = path.suffix.lower()

    # ドットなしファイル名（Dockerfile など）も拾う
    if ext in TEXT_EXT or path.name in {"Dockerfile", "Makefile", "Procfile", ".env"}:
        return _read_text_file(path)
    if ext == ".pdf":
        return _extract_pdf(path)
    if ext == ".docx":
        return _extract_docx(path)
    if ext == ".xlsx":
        return _extract_xlsx(path)
    if ext == ".pptx":
        return _extract_pptx(path)
    if ext == ".doc":
        return _extract_doc(path)
    if ext == ".xls":
        return _extract_xls(path)
    if ext == ".ppt":
        return _extract_ppt(path)
    if ext == ".rtf":
        return _extract_rtf(path)
    return None


def _read_text_file(path: Path) -> str | None:
    # 日本語環境のファイルを考慮した順番
    for enc in ("utf-8-sig", "utf-8", "cp932", "shift_jis", "euc-jp", "utf-16"):
        try:
            return path.read_text(encoding=enc)
        except (UnicodeDecodeError, UnicodeError):
            continue
        except OSError:
            return None
    # 最終手段：壊れた文字は無視
    try:
        return path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return None


def _extract_pdf(path: Path) -> str | None:
    try:
        import pypdf
    except ImportError:
        return None
    try:
        with open(path, "rb") as f:
            reader = pypdf.PdfReader(f)
            if reader.is_encrypted:
                try:
                    reader.decrypt("")
                except Exception:
                    return None
            parts = []
            for page in reader.pages:
                try:
                    parts.append(page.extract_text() or "")
                except Exception:
                    continue
            return "\n".join(parts)
    except Exception:
        return None


def _extract_docx(path: Path) -> str | None:
    try:
        import docx
    except ImportError:
        return None
    try:
        doc = docx.Document(str(path))
        parts = [p.text for p in doc.paragraphs if p.text]
        for table in doc.tables:
            for row in table.rows:
                for cell in row.cells:
                    if cell.text:
                        parts.append(cell.text)
        return "\n".join(parts)
    except Exception:
        return None


def _extract_xlsx(path: Path) -> str | None:
    try:
        import openpyxl
    except ImportError:
        return None
    try:
        wb = openpyxl.load_workbook(str(path), data_only=True, read_only=True)
        parts = []
        for sheet in wb.worksheets:
            parts.append(f"[Sheet: {sheet.title}]")
            for row in sheet.iter_rows(values_only=True):
                cells = [str(c) for c in row if c is not None]
                if cells:
                    parts.append(" | ".join(cells))
        wb.close()
        return "\n".join(parts)
    except Exception:
        return None


def _extract_pptx(path: Path) -> str | None:
    try:
        from pptx import Presentation
    except ImportError:
        return None
    try:
        prs = Presentation(str(path))
        parts = []
        for i, slide in enumerate(prs.slides, 1):
            parts.append(f"[Slide {i}]")
            for shape in slide.shapes:
                if shape.has_text_frame and shape.text_frame.text:
                    parts.append(shape.text_frame.text)
        return "\n".join(parts)
    except Exception:
        return None


# ---- 旧Office (Office 97-2003 バイナリ形式) ----

def _extract_xls(path: Path) -> str | None:
    """Excel 97-2003 (.xls) - xlrd で読む。完全対応。"""
    try:
        import xlrd
    except ImportError:
        return None
    try:
        wb = xlrd.open_workbook(str(path), on_demand=True)
        parts = []
        for name in wb.sheet_names():
            sheet = wb.sheet_by_name(name)
            parts.append(f"[Sheet: {name}]")
            for row_idx in range(sheet.nrows):
                row = sheet.row_values(row_idx)
                cells = [str(c) for c in row if c not in (None, "")]
                if cells:
                    parts.append(" | ".join(cells))
            wb.unload_sheet(name)
        return "\n".join(parts)
    except Exception:
        return None


# 印字可能ASCII + 全角記号 + ひらがな + カタカナ + 漢字 + 半角ｶﾅ + 改行類
_READABLE_RE = re.compile(
    r"[\x20-\x7e\u3000-\u30ff\u4e00-\u9fff\uff00-\uffef\n\r\t]{4,}"
)


def _extract_ole_text(path: Path, stream_names: tuple[str, ...]) -> str | None:
    """OLEファイル (.doc/.ppt) からテキスト抽出。書式コード混在のため
    ベストエフォート（本文の大半は取れるが、見出しやヘッダの一部が失われることあり）。"""
    try:
        import olefile
    except ImportError:
        return None
    try:
        if not olefile.isOleFile(str(path)):
            return None
        with olefile.OleFileIO(str(path)) as ole:
            for sname in stream_names:
                if not ole.exists(sname):
                    continue
                data = ole.openstream(sname).read()
                # UTF-16LE と CP932 の両方を試して、より長い「読める」テキストを採用
                pieces_u16 = _READABLE_RE.findall(
                    data.decode("utf-16-le", errors="ignore")
                )
                pieces_cp932 = _READABLE_RE.findall(
                    data.decode("cp932", errors="ignore")
                )
                u16_text = "\n".join(pieces_u16)
                cp_text = "\n".join(pieces_cp932)
                # 日本語文字（ひらがな/カタカナ/漢字）の出現数で判定
                jp_re = re.compile(r"[\u3040-\u30ff\u4e00-\u9fff]")
                u16_score = len(jp_re.findall(u16_text))
                cp_score = len(jp_re.findall(cp_text))
                # 日本語が多く取れた方を採用、どちらも少ないなら長い方
                if u16_score > cp_score:
                    return u16_text
                if cp_score > u16_score:
                    return cp_text
                return u16_text if len(u16_text) >= len(cp_text) else cp_text
        return None
    except Exception:
        return None


def _extract_doc(path: Path) -> str | None:
    """Word 97-2003 (.doc) - olefile + ヒューリスティック。ベストエフォート。"""
    return _extract_ole_text(path, ("WordDocument",))


def _extract_ppt(path: Path) -> str | None:
    """PowerPoint 97-2003 (.ppt) - olefile + ヒューリスティック。ベストエフォート。"""
    return _extract_ole_text(path, ("PowerPoint Document",))


def _extract_rtf(path: Path) -> str | None:
    """RTF - striprtf で読む。完全対応。"""
    try:
        from striprtf.striprtf import rtf_to_text
    except ImportError:
        return None
    try:
        # RTF はASCII互換のテキストフォーマット
        for enc in ("utf-8", "cp932", "latin-1"):
            try:
                with open(path, "r", encoding=enc) as f:
                    rtf = f.read()
                return rtf_to_text(rtf, errors="ignore")
            except UnicodeDecodeError:
                continue
        return None
    except Exception:
        return None


# ---------------------------------------------------------------------------
# インデックス（SQLite FTS5）
# ---------------------------------------------------------------------------

class Indexer:
    def __init__(self, db_path: Path):
        self.db_path = db_path
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path), timeout=30)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA temp_store=MEMORY")
        return conn

    def _init_db(self) -> None:
        conn = self._connect()
        try:
            # trigramトークナイザは日本語/中国語の部分一致に強い (SQLite 3.34+)
            # 利用不可の場合は unicode61 にフォールバック
            try:
                conn.execute(
                    "CREATE VIRTUAL TABLE IF NOT EXISTS contents USING fts5("
                    "path UNINDEXED, name, content, tokenize='trigram')"
                )
                self.tokenizer = "trigram"
            except sqlite3.OperationalError:
                conn.execute(
                    "CREATE VIRTUAL TABLE IF NOT EXISTS contents USING fts5("
                    "path UNINDEXED, name, content, "
                    "tokenize='unicode61 remove_diacritics 2')"
                )
                self.tokenizer = "unicode61"

            conn.executescript("""
                CREATE TABLE IF NOT EXISTS files (
                    path      TEXT PRIMARY KEY,
                    name      TEXT,
                    mtime     REAL,
                    size      INTEGER,
                    indexed   REAL
                );
                CREATE INDEX IF NOT EXISTS idx_files_name ON files(name);
            """)
            conn.commit()
        finally:
            conn.close()

    # --- 書き込み ---
    def get_known(self) -> dict[str, float]:
        """{path: mtime} の辞書を返す。差分判定用。"""
        conn = self._connect()
        try:
            rows = conn.execute("SELECT path, mtime FROM files").fetchall()
            return {p: m for p, m in rows}
        finally:
            conn.close()

    def upsert_batch(self, items: list[tuple[str, str, float, int, str]]) -> None:
        """items = [(path, name, mtime, size, content), ...]"""
        if not items:
            return
        conn = self._connect()
        try:
            with conn:
                paths = [(p,) for p, *_ in items]
                conn.executemany("DELETE FROM contents WHERE path=?", paths)
                conn.executemany(
                    "INSERT INTO contents(path, name, content) VALUES(?,?,?)",
                    [(p, n, c or "") for p, n, _, _, c in items],
                )
                now = time.time()
                conn.executemany(
                    "INSERT OR REPLACE INTO files(path, name, mtime, size, indexed) "
                    "VALUES(?,?,?,?,?)",
                    [(p, n, m, s, now) for p, n, m, s, _ in items],
                )
        finally:
            conn.close()

    def delete_paths(self, paths: list[str]) -> None:
        if not paths:
            return
        conn = self._connect()
        try:
            with conn:
                conn.executemany("DELETE FROM contents WHERE path=?", [(p,) for p in paths])
                conn.executemany("DELETE FROM files WHERE path=?", [(p,) for p in paths])
        finally:
            conn.close()

    def clear(self) -> None:
        conn = self._connect()
        try:
            with conn:
                conn.execute("DELETE FROM contents")
                conn.execute("DELETE FROM files")
        finally:
            conn.close()

    def stats(self) -> tuple[int, int]:
        """(ファイル数, 合計バイト数) を返す。"""
        conn = self._connect()
        try:
            row = conn.execute("SELECT COUNT(*), COALESCE(SUM(size),0) FROM files").fetchone()
            return row[0], row[1]
        finally:
            conn.close()

    # --- 検索 ---
    def search(self, query: str, limit: int = SEARCH_LIMIT) -> list[tuple[str, str, str]]:
        """[(path, name, snippet), ...] を返す。

        日本語2文字以下のキーワードは trigram で扱えないため LIKE で補完する。
        """
        if not query.strip():
            return []
        conn = self._connect()
        try:
            tokens = _parse_query_tokens(query)
            # FTS用とLIKE用に振り分け
            fts_pos = []     # (phrase, is_phrase) - 通常語（≥3文字）
            like_pos = []    # 短すぎる肯定語
            neg = []         # 否定語（全部FTSに渡せる）
            for term, is_phrase, is_neg in tokens:
                if is_neg:
                    neg.append((term, is_phrase))
                elif _len_no_space(term) >= 3:
                    fts_pos.append((term, is_phrase))
                else:
                    like_pos.append(term)

            # まずFTSで候補を絞る（肯定語が1つ以上ある場合）
            if fts_pos:
                fts_q = _build_fts_expr(fts_pos, neg)
                try:
                    rows = conn.execute(
                        f"""
                        SELECT path, name,
                               snippet(contents, 2, '〘', '〙', '…', {SNIPPET_LEN})
                        FROM contents
                        WHERE contents MATCH ?
                        ORDER BY rank
                        LIMIT ?
                        """,
                        (fts_q, limit * 3),
                    ).fetchall()
                except sqlite3.OperationalError:
                    rows = []
            else:
                # 全てが短い語の場合：全ファイル走査
                rows = conn.execute(
                    "SELECT path, name, substr(content, 1, 200) FROM contents"
                ).fetchall()

            # like_pos と neg(短いもの) でフィルタ
            if like_pos or neg:
                # コンテンツ本文を取得しながら絞る
                paths = [r[0] for r in rows]
                contents_map = {}
                if paths:
                    placeholders = ",".join("?" for _ in paths)
                    for p, c in conn.execute(
                        f"SELECT path, content FROM contents WHERE path IN ({placeholders})",
                        paths,
                    ):
                        contents_map[p] = c or ""

                filtered = []
                for path, name, snip in rows:
                    body = contents_map.get(path, "")
                    haystack = (body + "\n" + name).lower()
                    ok = True
                    for term in like_pos:
                        if term.lower() not in haystack:
                            ok = False
                            break
                    if ok:
                        for term, _ in neg:
                            if term.lower() in haystack:
                                ok = False
                                break
                    if ok:
                        # FTSでヒット箇所がない（=純LIKE検索）場合はスニペットを作り直す
                        if like_pos and not fts_pos:
                            snip = _make_snippet(body, like_pos[0])
                        filtered.append((path, name, snip))
                    if len(filtered) >= limit:
                        break
                rows = filtered

            return rows[:limit]
        finally:
            conn.close()


def _len_no_space(s: str) -> int:
    return len(re.sub(r"\s", "", s))


def _parse_query_tokens(q: str) -> list[tuple[str, bool, bool]]:
    """[(term, is_phrase, is_negated), ...] を返す。"""
    out = []
    for tok in re.findall(r'-?"[^"]+"|-?\S+', q):
        neg = tok.startswith("-")
        if neg:
            tok = tok[1:]
        if tok.startswith('"') and tok.endswith('"') and len(tok) >= 2:
            out.append((tok[1:-1], True, neg))
        else:
            out.append((tok, False, neg))
    return out


def _build_fts_expr(pos: list[tuple[str, bool]], neg: list[tuple[str, bool]]) -> str:
    pos_exprs = [_fts_phrase(t) for t, _ in pos]
    expr = " AND ".join(pos_exprs) if pos_exprs else ""
    for t, _ in neg:
        if _len_no_space(t) >= 3:
            expr = f"{expr} NOT {_fts_phrase(t)}".strip() if expr else _fts_phrase(t)
    return expr or '""'


def _fts_phrase(term: str) -> str:
    safe = term.replace('"', '""')
    return f'"{safe}"'


def _make_snippet(body: str, term: str, ctx: int = 60) -> str:
    if not body or not term:
        return body[:160] if body else ""
    i = body.lower().find(term.lower())
    if i < 0:
        return body[:160]
    s = max(0, i - ctx)
    e = min(len(body), i + len(term) + ctx)
    before = body[s:i].replace("\n", " ")
    hit = body[i:i + len(term)]
    after = body[i + len(term):e].replace("\n", " ")
    pre = "…" if s > 0 else ""
    suf = "…" if e < len(body) else ""
    return f"{pre}{before}〘{hit}〙{after}{suf}"


# ---------------------------------------------------------------------------
# 走査ワーカー
# ---------------------------------------------------------------------------

def _extract_task(path_str: str, name: str, mtime: float, size: int):
    """ThreadPoolExecutor 用ワーカー。失敗しても None を返さず空文字で続行。"""
    try:
        text = extract_text(Path(path_str))
    except Exception:
        text = None
    return (path_str, name, mtime, size, text or "")


class IndexWorker(threading.Thread):
    """バックグラウンドでフォルダを走査してインデックス化。
    抽出は ThreadPoolExecutor で並列実行（I/Oバウンドなので効果大）。
    """

    def __init__(self, roots: list[str], indexer: Indexer, progress_q: queue.Queue,
                 full_rescan: bool = False):
        super().__init__(daemon=True)
        self.roots = [Path(r) for r in roots]
        self.indexer = indexer
        self.q = progress_q
        self.full_rescan = full_rescan
        self.stop_flag = threading.Event()

    def stop(self):
        self.stop_flag.set()

    def run(self):
        try:
            self._run()
        except Exception:
            self.q.put(("error", traceback.format_exc()))
        finally:
            self.q.put(("done", None))

    def _run(self):
        known = {} if self.full_rescan else self.indexer.get_known()
        seen: set[str] = set()
        batch: list[tuple[str, str, float, int, str]] = []

        scanned = 0
        indexed = 0
        skipped = 0
        t0 = time.time()
        last_update = 0.0
        last_dir = ""
        current_file = ""

        def push_status(force=False):
            nonlocal last_update
            now = time.time()
            if not force and now - last_update < 0.3:
                return
            last_update = now
            cf = f"  📄 {current_file}" if current_file else ""
            self.q.put(("status",
                f"走査中: {scanned:,} 件 / 取込 {indexed:,} 件 "
                f"({now - t0:.1f}s)  📂 {last_dir}{cf}"))

        def walk_err(err):
            tgt = getattr(err, "filename", None) or str(err)
            self.q.put(("log", f"⚠ アクセス不可: {tgt}"))

        def collect(fut):
            """完了したFutureから結果を取り出してバッチに追加。"""
            nonlocal indexed
            try:
                res = fut.result()
            except Exception:
                return
            if res is None:
                return
            batch.append(res)
            indexed += 1
            if len(batch) >= BATCH_SIZE:
                self.indexer.upsert_batch(batch)
                batch.clear()
                push_status(force=True)

        # 並列で抽出 - I/Oバウンドなのでスレッド数を多めに
        max_inflight = NUM_EXTRACT_WORKERS * 4

        with ThreadPoolExecutor(max_workers=NUM_EXTRACT_WORKERS,
                                thread_name_prefix="extract") as pool:
            inflight: list = []

            def shutdown():
                """停止要求時の片付け。"""
                pool.shutdown(wait=False, cancel_futures=True)

            for root in self.roots:
                if not root.exists():
                    self.q.put(("log", f"⚠ パスが見つからない: {root}"))
                    continue
                self.q.put(("log", f"スキャン開始: {root}"))
                push_status(force=True)

                for dirpath, dirnames, filenames in os.walk(
                    root, topdown=True, onerror=walk_err
                ):
                    if self.stop_flag.is_set():
                        shutdown()
                        return
                    dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
                    last_dir = dirpath
                    current_file = ""
                    push_status()

                    for fn in filenames:
                        if self.stop_flag.is_set():
                            shutdown()
                            return
                        p = Path(dirpath) / fn
                        sp = str(p)
                        seen.add(sp)
                        scanned += 1
                        current_file = fn
                        push_status()

                        try:
                            st = p.stat()
                        except OSError:
                            skipped += 1
                            continue

                        # 増分判定
                        prev = known.get(sp)
                        if prev is not None and abs(prev - st.st_mtime) < 0.001:
                            continue

                        # バックプレッシャ：保留中が多すぎたら少し待つ
                        if len(inflight) >= max_inflight:
                            done, _ = wait(inflight, return_when=FIRST_COMPLETED)
                            for f in done:
                                collect(f)
                                inflight.remove(f)

                        # 抽出をプールに投げる
                        fut = pool.submit(_extract_task, sp, fn,
                                          st.st_mtime, st.st_size)
                        inflight.append(fut)

            # 全投入完了 → 残りを回収
            while inflight:
                if self.stop_flag.is_set():
                    shutdown()
                    return
                done, _ = wait(inflight, return_when=FIRST_COMPLETED)
                for f in done:
                    collect(f)
                    inflight.remove(f)
                push_status()

        if batch:
            self.indexer.upsert_batch(batch)

        # 既知だが今回見つからなかったファイルをDBから削除
        if not self.full_rescan:
            roots_str = [str(r) for r in self.roots]
            stale = [p for p in known
                     if any(p == r or p.startswith(r + os.sep) for r in roots_str)
                     and p not in seen]
            if stale:
                self.indexer.delete_paths(stale)
                self.q.put(("log", f"削除済みファイルをインデックスから除去: {len(stale)} 件"))

        elapsed = time.time() - t0
        self.q.put(("log",
            f"完了: 走査 {scanned} 件 / 新規・更新 {indexed} 件 / "
            f"スキップ {skipped} 件 / {elapsed:.1f}s"))


# ---------------------------------------------------------------------------
# 設定保存
# ---------------------------------------------------------------------------

def load_config() -> dict:
    if CONFIG_PATH.exists():
        try:
            return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {"roots": []}


def save_config(cfg: dict) -> None:
    CONFIG_PATH.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")


# ---------------------------------------------------------------------------
# GUI
# ---------------------------------------------------------------------------

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"{APP_NAME} — 全文検索")
        self.geometry("1100x720")
        try:
            self.iconbitmap(default="")
        except Exception:
            pass

        self.indexer = Indexer(DB_PATH)
        self.cfg = load_config()
        self.worker: IndexWorker | None = None
        self.q: queue.Queue = queue.Queue()
        self._last_stats_update = 0.0

        self._build_ui()
        self._refresh_stats()
        self.after(100, self._poll_queue)

    # ---- UI ----
    def _build_ui(self):
        style = ttk.Style(self)
        try:
            style.theme_use("vista")
        except tk.TclError:
            pass

        # 上：対象フォルダ
        top = ttk.LabelFrame(self, text="検索対象フォルダ（ローカル / \\\\server\\share）")
        top.pack(fill="x", padx=8, pady=(8, 4))

        self.roots_var = tk.StringVar()
        self.roots_list = tk.Listbox(top, height=4, selectmode="extended")
        for r in self.cfg.get("roots", []):
            self.roots_list.insert("end", r)
        self.roots_list.pack(side="left", fill="x", expand=True, padx=(8, 4), pady=8)

        btns = ttk.Frame(top)
        btns.pack(side="right", padx=8, pady=8)
        ttk.Button(btns, text="フォルダ追加…", command=self.add_folder).pack(fill="x")
        ttk.Button(btns, text="UNCパス追加…", command=self.add_unc).pack(fill="x", pady=(4, 0))
        ttk.Button(btns, text="削除", command=self.remove_folder).pack(fill="x", pady=(4, 0))

        # 中：操作バー
        ops = ttk.Frame(self)
        ops.pack(fill="x", padx=8, pady=4)
        self.btn_index = ttk.Button(ops, text="インデックス更新（増分）", command=self.start_index)
        self.btn_index.pack(side="left")
        self.btn_full = ttk.Button(ops, text="フルスキャン", command=lambda: self.start_index(full=True))
        self.btn_full.pack(side="left", padx=(4, 0))
        self.btn_stop = ttk.Button(ops, text="停止", command=self.stop_index, state="disabled")
        self.btn_stop.pack(side="left", padx=(4, 0))
        ttk.Button(ops, text="DBクリア", command=self.clear_db).pack(side="left", padx=(4, 0))

        # スキャン中のアニメーション
        self.progress = ttk.Progressbar(ops, mode="indeterminate", length=160)
        self.progress.pack(side="left", padx=(8, 0))

        self.stats_var = tk.StringVar(value="")
        ttk.Label(ops, textvariable=self.stats_var).pack(side="right")

        # 検索バー
        sf = ttk.LabelFrame(self, text="検索（スペース区切り=AND、\"フレーズ\"、-除外）")
        sf.pack(fill="x", padx=8, pady=4)
        self.query_var = tk.StringVar()
        e = ttk.Entry(sf, textvariable=self.query_var, font=("", 12))
        e.pack(side="left", fill="x", expand=True, padx=8, pady=8)
        e.bind("<Return>", lambda _: self.do_search())
        ttk.Button(sf, text="検索", command=self.do_search).pack(side="right", padx=(0, 8), pady=8)

        # 結果ペイン（左：ファイル一覧、右：プレビュー）
        body = ttk.Panedwindow(self, orient="horizontal")
        body.pack(fill="both", expand=True, padx=8, pady=4)

        left = ttk.Frame(body)
        body.add(left, weight=1)
        self.results = ttk.Treeview(
            left, columns=("path",), show="tree headings", height=20
        )
        self.results.heading("#0", text="ファイル名")
        self.results.heading("path", text="パス")
        self.results.column("#0", width=240, stretch=False, minwidth=120)
        self.results.column("path", width=600, minwidth=200)

        vsb = ttk.Scrollbar(left, orient="vertical", command=self.results.yview)
        hsb = ttk.Scrollbar(left, orient="horizontal", command=self.results.xview)
        self.results.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)

        # gridで確実に縦・横スクロールバーを表示
        self.results.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")
        left.grid_rowconfigure(0, weight=1)
        left.grid_columnconfigure(0, weight=1)

        self.results.bind("<<TreeviewSelect>>", self.on_select)
        self.results.bind("<Double-1>", self.on_open)
        # マウスホイール（Windowsだと自動だが念のため）
        self.results.bind("<MouseWheel>",
            lambda e: self.results.yview_scroll(int(-e.delta/120), "units"))

        # 右クリックメニュー
        self.ctx_menu = tk.Menu(self, tearoff=0)
        self.ctx_menu.add_command(label="ファイルを開く", command=self.on_open)
        self.ctx_menu.add_command(label="場所を開く（エクスプローラ）",
                                   command=self.open_location)
        self.ctx_menu.add_separator()
        self.ctx_menu.add_command(label="パスをコピー", command=self.copy_path)
        self.ctx_menu.add_command(label="ファイル名をコピー", command=self.copy_name)
        # Windows/Linux=Button-3, macOS=Button-2
        self.results.bind("<Button-3>", self._show_ctx_menu)
        self.results.bind("<Button-2>", self._show_ctx_menu)

        right = ttk.Frame(body)
        body.add(right, weight=1)
        ttk.Label(right, text="プレビュー（ヒット箇所）").pack(anchor="w")
        self.preview = scrolledtext.ScrolledText(right, wrap="word", font=("Consolas", 10))
        self.preview.pack(fill="both", expand=True)
        self.preview.tag_configure("hit", background="#fff3a0", foreground="#000")
        self.preview.tag_configure("path", foreground="#0066cc", font=("", 10, "bold"))

        # 下：ログ
        log_frame = ttk.LabelFrame(self, text="ログ")
        log_frame.pack(fill="x", padx=8, pady=(4, 8))
        self.log = scrolledtext.ScrolledText(log_frame, height=5, wrap="word")
        self.log.pack(fill="x", padx=4, pady=4)

        # 状態バー
        self.status_var = tk.StringVar(value="準備完了")
        ttk.Label(self, textvariable=self.status_var, relief="sunken", anchor="w").pack(fill="x")

        self._results_data: list[tuple[str, str, str]] = []

    # ---- フォルダ操作 ----
    def add_folder(self):
        d = filedialog.askdirectory(title="検索対象フォルダを選択")
        if d:
            self.roots_list.insert("end", d)
            self._save_roots()

    def add_unc(self):
        win = tk.Toplevel(self)
        win.title("UNCパスを追加")
        win.geometry("500x120")
        win.transient(self)
        ttk.Label(win, text=r"例: \\server\share\folder").pack(pady=(10, 0))
        v = tk.StringVar()
        e = ttk.Entry(win, textvariable=v, width=60)
        e.pack(pady=8, padx=10, fill="x")
        e.focus()
        def ok():
            p = v.get().strip().strip('"')
            if p:
                self.roots_list.insert("end", p)
                self._save_roots()
                win.destroy()
        ttk.Button(win, text="追加", command=ok).pack()
        e.bind("<Return>", lambda _: ok())

    def remove_folder(self):
        for i in reversed(self.roots_list.curselection()):
            self.roots_list.delete(i)
        self._save_roots()

    def _save_roots(self):
        self.cfg["roots"] = list(self.roots_list.get(0, "end"))
        save_config(self.cfg)

    # ---- インデックス ----
    def start_index(self, full: bool = False):
        if self.worker and self.worker.is_alive():
            return
        roots = list(self.roots_list.get(0, "end"))
        if not roots:
            messagebox.showwarning(APP_NAME, "検索対象フォルダを1件以上追加してください。")
            return
        self.btn_index.config(state="disabled")
        self.btn_full.config(state="disabled")
        self.btn_stop.config(state="normal")
        self.progress.start(10)
        self._log(f"--- {'フルスキャン' if full else '増分インデックス'} 開始 ---")
        self.worker = IndexWorker(roots, self.indexer, self.q, full_rescan=full)
        self.worker.start()

    def stop_index(self):
        if self.worker and self.worker.is_alive():
            self.worker.stop()
            self._log("停止要求...")

    def clear_db(self):
        if not messagebox.askyesno(APP_NAME, "インデックスを全消去します。よろしいですか？"):
            return
        self.indexer.clear()
        self._log("インデックスをクリアしました。")
        self._refresh_stats()

    def _refresh_stats(self):
        n, total = self.indexer.stats()
        self.stats_var.set(f"インデックス済: {n:,} ファイル / {total/1e6:.1f} MB")

    # ---- 検索 ----
    def do_search(self):
        q = self.query_var.get().strip()
        self.results.delete(*self.results.get_children())
        self._results_data.clear()
        self.preview.delete("1.0", "end")
        if not q:
            return
        t0 = time.time()
        rows = self.indexer.search(q)
        for path, name, snip in rows:
            iid = self.results.insert("", "end", text=name, values=(path,))
            self._results_data.append((iid, path, snip))
        self.status_var.set(f"{len(rows)} 件ヒット ({(time.time()-t0)*1000:.0f} ms)")

    def on_select(self, _):
        sel = self.results.selection()
        if not sel:
            return
        iid = sel[0]
        for rec in self._results_data:
            if rec[0] == iid:
                _, path, snip = rec
                self.preview.delete("1.0", "end")
                self.preview.insert("end", path + "\n", "path")
                self.preview.insert("end", "─" * 60 + "\n")
                # スニペット内の 〘...〙 をハイライト
                idx = "3.0"
                self.preview.insert("end", snip + "\n\n")
                self._highlight_markers()

                # 余裕があればファイルの中身も読み込んで該当箇所を多めに表示
                self._show_more_hits(path)
                break

    def _highlight_markers(self):
        # 〘...〙 をハイライト
        text = self.preview.get("1.0", "end")
        for m in re.finditer(r"〘([^〙]*)〙", text):
            start = f"1.0+{m.start()}c"
            end = f"1.0+{m.end()}c"
            self.preview.tag_add("hit", start, end)

    def _show_more_hits(self, path: str):
        """ファイルを開きなおして、検索語の周辺も表示する。"""
        q = self.query_var.get().strip()
        if not q:
            return
        terms = [t.strip('"') for t in re.findall(r'"[^"]+"|\S+', q) if not t.startswith("-")]
        if not terms:
            return
        try:
            text = extract_text(Path(path)) or ""
        except Exception:
            return
        if not text:
            return

        self.preview.insert("end", "── ファイル内のヒット箇所 ──\n\n")
        pattern = re.compile("|".join(re.escape(t) for t in terms), re.IGNORECASE)
        shown = 0
        for m in pattern.finditer(text):
            if shown >= 20:
                self.preview.insert("end", "（...以下省略）\n")
                break
            s = max(0, m.start() - 80)
            e = min(len(text), m.end() + 80)
            ctx = text[s:e].replace("\n", " ")
            insert_pos = self.preview.index("end")
            self.preview.insert("end", f"…{ctx}…\n\n")
            # ハイライト
            for mm in pattern.finditer(ctx):
                start = f"{insert_pos}+{1 + mm.start()}c"
                end = f"{insert_pos}+{1 + mm.end()}c"
                self.preview.tag_add("hit", start, end)
            shown += 1

    def on_open(self, _=None):
        sel = self.results.selection()
        if not sel:
            return
        path = self.results.item(sel[0], "values")[0]
        try:
            if sys.platform == "win32":
                os.startfile(path)
            elif sys.platform == "darwin":
                subprocess.Popen(["open", path])
            else:
                subprocess.Popen(["xdg-open", path])
        except Exception as e:
            messagebox.showerror(APP_NAME, f"開けませんでした:\n{e}")

    def open_location(self, _=None):
        """エクスプローラで該当ファイルを選択した状態で親フォルダを開く。"""
        sel = self.results.selection()
        if not sel:
            return
        path = self.results.item(sel[0], "values")[0]
        try:
            if sys.platform == "win32":
                # /select でファイルを選択状態にして開く
                # explorer はカンマ後のスペースでも動くがクオートを正しく処理させるため
                # Popen のリスト渡しでなく文字列で渡す（パスにスペースがあっても OK）
                subprocess.Popen(f'explorer /select,"{path}"')
            elif sys.platform == "darwin":
                subprocess.Popen(["open", "-R", path])
            else:
                # Linux: 親フォルダを開く（ファイル選択は環境依存）
                parent = str(Path(path).parent)
                subprocess.Popen(["xdg-open", parent])
        except Exception as e:
            messagebox.showerror(APP_NAME, f"場所を開けませんでした:\n{e}")

    def copy_path(self, _=None):
        sel = self.results.selection()
        if not sel:
            return
        path = self.results.item(sel[0], "values")[0]
        self.clipboard_clear()
        self.clipboard_append(path)
        self.status_var.set(f"パスをコピー: {path}")

    def copy_name(self, _=None):
        sel = self.results.selection()
        if not sel:
            return
        name = self.results.item(sel[0], "text")
        self.clipboard_clear()
        self.clipboard_append(name)
        self.status_var.set(f"ファイル名をコピー: {name}")

    def _show_ctx_menu(self, event):
        # 右クリックされた行を選択状態に
        iid = self.results.identify_row(event.y)
        if iid:
            self.results.selection_set(iid)
            try:
                self.ctx_menu.tk_popup(event.x_root, event.y_root)
            finally:
                self.ctx_menu.grab_release()

    # ---- 進捗キュー ----
    def _poll_queue(self):
        try:
            while True:
                kind, payload = self.q.get_nowait()
                if kind == "log":
                    self._log(payload)
                elif kind == "status":
                    self.status_var.set(payload)
                elif kind == "error":
                    self._log("エラー:\n" + payload)
                elif kind == "done":
                    self.btn_index.config(state="normal")
                    self.btn_full.config(state="normal")
                    self.btn_stop.config(state="disabled")
                    self.progress.stop()
                    self._refresh_stats()
                    self.status_var.set("インデックス更新完了")
        except queue.Empty:
            pass

        # スキャン中は1秒ごとに「インデックス済」カウントをDBから更新
        if self.worker and self.worker.is_alive():
            now = time.time()
            if now - self._last_stats_update > 1.0:
                self._refresh_stats()
                self._last_stats_update = now

        self.after(50, self._poll_queue)

    def _log(self, msg: str):
        ts = datetime.now().strftime("%H:%M:%S")
        self.log.insert("end", f"[{ts}] {msg}\n")
        self.log.see("end")


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------

def main():
    app = App()
    app.mainloop()


if __name__ == "__main__":
    main()
